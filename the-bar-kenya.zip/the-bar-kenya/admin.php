<?php
// admin.php — Admin Panel: Products + Orders
require_once 'config/db.php';

// Auth guard
if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: auth.php?action=login'); exit;
}

$db  = getDB();
$tab = $_GET['tab'] ?? 'products';
$msg = '';

// ── PRODUCT ACTIONS ───────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';

    if ($act === 'save_product') {
        $id       = (int)($_POST['id'] ?? 0);
        $name     = trim($_POST['name']     ?? '');
        $price    = (float)($_POST['price'] ?? 0);
        $category = trim($_POST['category'] ?? '');
        $img      = trim($_POST['img_url']  ?? '');
        $stock    = (int)($_POST['stock']   ?? 0);
        $active   = isset($_POST['active']) ? 1 : 0;

        if (!$name || $price <= 0) {
            $msg = ['type' => 'error', 'text' => 'Name and price are required.'];
        } else {
            if ($id > 0) {
                $db->prepare("UPDATE products SET name=?,price=?,category=?,img_url=?,stock=?,active=? WHERE id=?")
                   ->execute([$name, $price, $category, $img, $stock, $active, $id]);
            } else {
                $db->prepare("INSERT INTO products (name,price,category,img_url,stock,active) VALUES (?,?,?,?,?,?)")
                   ->execute([$name, $price, $category, $img, $stock, $active]);
            }
            $msg = ['type' => 'success', 'text' => 'Product saved.'];
        }
        $tab = 'products';

    } elseif ($act === 'delete_product') {
        $id = (int)($_POST['id'] ?? 0);
        $db->prepare("UPDATE products SET active = 0 WHERE id = ?")->execute([$id]);
        $msg = ['type' => 'success', 'text' => 'Product deactivated.'];
        $tab = 'products';

    } elseif ($act === 'update_order_status') {
        $orderId = (int)($_POST['order_id'] ?? 0);
        $status  = $_POST['status'] ?? '';
        $allowed = ['pending', 'paid', 'failed', 'cancelled'];
        if (in_array($status, $allowed, true)) {
            $db->prepare("UPDATE orders SET status = ? WHERE id = ?")->execute([$status, $orderId]);
        }
        $msg = ['type' => 'success', 'text' => "Order #$orderId status updated."];
        $tab = 'orders';
    }
}

// Edit product pre-load
$editProduct = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editProduct = $stmt->fetch();
    $tab = 'products';
}

$products = $db->query("SELECT * FROM products ORDER BY active DESC, category, name")->fetchAll();
$orders   = $db->query("
    SELECT o.*, u.name AS user_name, u.email AS user_email
    FROM orders o
    LEFT JOIN users u ON u.id = o.user_id
    ORDER BY o.created_at DESC
    LIMIT 200
")->fetchAll();
$users = $db->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 100")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin | The Bar Kenya</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  :root { --gold:#c9a84c; --dark:#0d0d0d; --card:#161616; --border:#2a2a2a; --text:#e8e0d0; --muted:#888; --green:#1db954; }
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'DM Sans',sans-serif;background:var(--dark);color:var(--text);min-height:100vh}
  header{background:#080808;border-bottom:1px solid var(--border);padding:16px 28px;display:flex;align-items:center;justify-content:space-between}
  .logo{font-family:'Playfair Display',serif;color:var(--gold);font-size:1.3rem;text-decoration:none}
  nav a{color:var(--muted);text-decoration:none;margin-left:18px;font-size:.85rem}
  nav a:hover{color:var(--gold)}
  .tabs{display:flex;gap:0;border-bottom:1px solid var(--border);padding:0 28px;background:#0d0d0d}
  .tab{padding:14px 22px;cursor:pointer;font-size:.85rem;letter-spacing:.06em;text-transform:uppercase;border-bottom:2px solid transparent;color:var(--muted);text-decoration:none}
  .tab.active{border-color:var(--gold);color:var(--gold)}
  .section{display:none;padding:28px}
  .section.active{display:block}
  .flash{padding:12px 18px;margin-bottom:20px;border-radius:2px;font-size:.88rem}
  .flash.success{background:rgba(29,185,84,.12);border:1px solid rgba(29,185,84,.3);color:var(--green)}
  .flash.error{background:rgba(192,57,43,.12);border:1px solid rgba(192,57,43,.3);color:#e74c3c}
  .card{background:var(--card);border:1px solid var(--border);border-radius:2px;padding:24px;margin-bottom:24px}
  h2{font-family:'Playfair Display',serif;color:var(--gold);margin-bottom:20px;font-size:1.4rem}
  h3{color:var(--text);margin-bottom:14px;font-size:1rem}
  label{display:block;font-size:.75rem;color:var(--muted);letter-spacing:.07em;text-transform:uppercase;margin-bottom:5px}
  input[type=text],input[type=number],input[type=url],select,textarea{
    width:100%;background:#0d0d0d;border:1px solid var(--border);color:var(--text);
    padding:10px 13px;border-radius:2px;font-size:.9rem;margin-bottom:14px;font-family:inherit
  }
  input:focus,select:focus{outline:none;border-color:var(--gold)}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
  .btn{padding:10px 20px;border:none;border-radius:2px;cursor:pointer;font-size:.85rem;font-weight:600;letter-spacing:.05em}
  .btn-gold{background:var(--gold);color:#000}.btn-gold:hover{background:#f0d080}
  .btn-red{background:rgba(192,57,43,.8);color:#fff}.btn-red:hover{background:#c0392b}
  .btn-sm{padding:6px 14px;font-size:.78rem}
  table{width:100%;border-collapse:collapse;font-size:.85rem}
  th,td{padding:11px 10px;border-bottom:1px solid var(--border);text-align:left}
  th{color:var(--muted);font-weight:400;font-size:.75rem;letter-spacing:.07em;text-transform:uppercase}
  tr:hover td{background:rgba(255,255,255,.02)}
  .badge{display:inline-block;padding:3px 10px;border-radius:99px;font-size:.72rem;font-weight:600;letter-spacing:.05em}
  .badge.paid{background:rgba(29,185,84,.18);color:#1db954}
  .badge.pending{background:rgba(201,168,76,.18);color:var(--gold)}
  .badge.failed,.badge.cancelled{background:rgba(192,57,43,.18);color:#e74c3c}
  .product-thumb{width:40px;height:40px;object-fit:contain;vertical-align:middle}
  .toggle-row{display:flex;align-items:center;gap:10px;margin-bottom:14px}
  @media(max-width:700px){.grid2{grid-template-columns:1fr}}
</style>
</head>
<body>

<header>
  <a class="logo" href="admin.php">⚙️ Admin Panel</a>
  <nav>
    <a href="index.php">← Store</a>
    <a href="auth.php?action=logout">Logout</a>
  </nav>
</header>

<div class="tabs">
  <a class="tab <?= $tab==='products'?'active':'' ?>" href="admin.php?tab=products">Products</a>
  <a class="tab <?= $tab==='orders'  ?'active':'' ?>" href="admin.php?tab=orders">Orders</a>
  <a class="tab <?= $tab==='users'   ?'active':'' ?>" href="admin.php?tab=users">Users</a>
</div>

<?php if ($msg): ?>
  <div style="padding:0 28px;margin-top:16px">
    <div class="flash <?= $msg['type'] ?>"><?= htmlspecialchars($msg['text']) ?></div>
  </div>
<?php endif; ?>

<!-- ── PRODUCTS TAB ──────────────────────────────────────────────────────────── -->
<div class="section <?= $tab==='products'?'active':'' ?>">
  <div class="card">
    <h2><?= $editProduct ? 'Edit Product' : 'Add New Product' ?></h2>
    <form method="POST" action="admin.php">
      <input type="hidden" name="act" value="save_product">
      <input type="hidden" name="id"  value="<?= $editProduct['id'] ?? 0 ?>">
      <div class="grid2">
        <div>
          <label>Product Name</label>
          <input type="text" name="name" required value="<?= htmlspecialchars($editProduct['name'] ?? '') ?>">
        </div>
        <div>
          <label>Category</label>
          <input type="text" name="category" placeholder="Beer, Spirits, Whisky…" value="<?= htmlspecialchars($editProduct['category'] ?? '') ?>">
        </div>
        <div>
          <label>Price (KES)</label>
          <input type="number" name="price" step="0.01" required min="1" value="<?= $editProduct['price'] ?? '' ?>">
        </div>
        <div>
          <label>Stock</label>
          <input type="number" name="stock" min="0" value="<?= $editProduct['stock'] ?? 100 ?>">
        </div>
      </div>
      <label>Image URL</label>
      <input type="url" name="img_url" placeholder="https://…" value="<?= htmlspecialchars($editProduct['img_url'] ?? '') ?>">
      <div class="toggle-row">
        <input type="checkbox" id="active" name="active" value="1" <?= ($editProduct['active'] ?? 1) ? 'checked' : '' ?> style="width:auto;margin:0">
        <label for="active" style="text-transform:none;letter-spacing:0;font-size:.9rem;color:var(--text)">Active (visible in store)</label>
      </div>
      <button type="submit" class="btn btn-gold"><?= $editProduct ? 'Update Product' : 'Add Product' ?></button>
      <?php if ($editProduct): ?>
        <a href="admin.php?tab=products" class="btn btn-sm" style="margin-left:10px;background:var(--border);color:var(--muted);text-decoration:none;display:inline-block;padding:10px 18px">Cancel</a>
      <?php endif; ?>
    </form>
  </div>

  <div class="card">
    <h2>All Products (<?= count($products) ?>)</h2>
    <table>
      <thead><tr><th></th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($products as $p): ?>
          <tr>
            <td><img class="product-thumb" src="<?= htmlspecialchars($p['img_url']) ?>" onerror="this.style.display='none'" alt=""></td>
            <td><?= htmlspecialchars($p['name']) ?></td>
            <td><?= htmlspecialchars($p['category']) ?></td>
            <td>KES <?= number_format($p['price'], 0) ?></td>
            <td><?= $p['stock'] ?></td>
            <td><span class="badge <?= $p['active'] ? 'paid' : 'failed' ?>"><?= $p['active'] ? 'Active' : 'Hidden' ?></span></td>
            <td>
              <a href="admin.php?tab=products&edit=<?= $p['id'] ?>" class="btn btn-sm btn-gold">Edit</a>
              <form method="POST" style="display:inline" onsubmit="return confirm('Deactivate this product?')">
                <input type="hidden" name="act" value="delete_product">
                <input type="hidden" name="id"  value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-sm btn-red">Deactivate</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── ORDERS TAB ────────────────────────────────────────────────────────────── -->
<div class="section <?= $tab==='orders'?'active':'' ?>">
  <div class="card">
    <h2>Orders (<?= count($orders) ?>)</h2>
    <table>
      <thead>
        <tr><th>#</th><th>Customer</th><th>Phone</th><th>Total</th><th>Status</th><th>M-Pesa Code</th><th>Date</th><th>Update</th></tr>
      </thead>
      <tbody>
        <?php foreach ($orders as $o): ?>
          <tr>
            <td><?= $o['id'] ?></td>
            <td><?= htmlspecialchars($o['user_name'] ?? '—') ?><br><small style="color:var(--muted)"><?= htmlspecialchars($o['user_email'] ?? '') ?></small></td>
            <td><?= htmlspecialchars($o['phone']) ?></td>
            <td>KES <?= number_format($o['total'], 0) ?></td>
            <td><span class="badge <?= $o['status'] ?>"><?= strtoupper($o['status']) ?></span></td>
            <td><?= htmlspecialchars($o['mpesa_code'] ?? '—') ?></td>
            <td style="font-size:.78rem;color:var(--muted)"><?= date('d M Y H:i', strtotime($o['created_at'])) ?></td>
            <td>
              <form method="POST" style="display:flex;gap:6px">
                <input type="hidden" name="act" value="update_order_status">
                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                <select name="status" style="padding:5px;margin:0;width:auto">
                  <?php foreach (['pending','paid','failed','cancelled'] as $s): ?>
                    <option value="<?= $s ?>" <?= $o['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                  <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-sm btn-gold">Set</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── USERS TAB ─────────────────────────────────────────────────────────────── -->
<div class="section <?= $tab==='users'?'active':'' ?>">
  <div class="card">
    <h2>Registered Users (<?= count($users) ?>)</h2>
    <table>
      <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Joined</th></tr></thead>
      <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td><?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['name']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td><?= htmlspecialchars($u['phone']) ?></td>
            <td><span class="badge <?= $u['role']==='admin'?'paid':'pending' ?>"><?= strtoupper($u['role']) ?></span></td>
            <td style="font-size:.78rem;color:var(--muted)"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

</body>
</html>
