<?php
// config/db.php — Database + App Configuration

define('DB_HOST', 'localhost');
define('DB_USER', 'root');          // ← change to your MySQL user
define('DB_PASS', '');              // ← change to your MySQL password
define('DB_NAME', 'the_bar_kenya');

define('MPESA_CONSUMER_KEY',    'YOUR_CONSUMER_KEY');      // ← from Safaricom Developer Portal
define('MPESA_CONSUMER_SECRET', 'YOUR_CONSUMER_SECRET');
define('MPESA_SHORTCODE',       '174379');                 // Use your paybill/till number
define('MPESA_PASSKEY',         'YOUR_LIPA_NA_MPESA_PASSKEY');
define('MPESA_CALLBACK_URL',    'https://yourdomain.com/mpesa_callback.php'); // ← your live URL
define('MPESA_ENV',             'sandbox');                // 'sandbox' or 'live'

// Session start (called once globally)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}
