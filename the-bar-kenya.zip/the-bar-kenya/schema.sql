-- schema.sql
-- Run this once in your MySQL client:
--   mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS the_bar_kenya CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE the_bar_kenya;

-- ─── USERS ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(120) NOT NULL,
    email      VARCHAR(180) NOT NULL UNIQUE,
    phone      VARCHAR(20)  NOT NULL,
    password   VARCHAR(255) NOT NULL,
    role       ENUM('customer','admin') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed default admin (password: Admin@1234)
INSERT IGNORE INTO users (name, email, phone, password, role)
VALUES (
    'Admin',
    'admin@thebar.co.ke',
    '0700000000',
    '$2y$12$Y7J2mR0GvL5T9bXzKwP8sOjNHdFqCeVlI3uA6RtZkDMpWnB1xGyfO',
    'admin'
);

-- ─── PRODUCTS ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(220) NOT NULL,
    price       DECIMAL(10,2) NOT NULL,
    category    VARCHAR(80)  DEFAULT 'Other',
    img_url     VARCHAR(500),
    stock       INT          DEFAULT 100,
    active      TINYINT(1)   DEFAULT 1,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- Seed starter products
INSERT IGNORE INTO products (name, price, category, img_url, stock) VALUES
('Tusker Lager 500ml',           260.00,  'Beer',    'https://drinkiq.com/wp-content/uploads/2020/08/Tusker-Lager.png', 200),
('White Cap Lager 500ml',        250.00,  'Beer',    'https://drinkiq.com/wp-content/uploads/2020/08/White-Cap-Lager.png', 200),
('Tusker Cider 330ml',           280.00,  'Cider',   'https://drinkiq.com/wp-content/uploads/2020/08/Tusker-Cider.png', 150),
('Baileys Irish Cream 750ml',   3000.00,  'Liqueur', 'https://www.diageobaracademy.com/uploads/images/baileys-original.png', 50),
('Smirnoff No.21 Vodka 750ml',  1800.00,  'Spirits', 'https://www.diageobaracademy.com/uploads/images/smirnoff-red.png', 80),
('Gilbey\'s Special Dry Gin 750ml', 2500.00, 'Spirits','https://www.diageobaracademy.com/uploads/images/gilbeys-gin.png', 60),
('Gordon\'s London Dry Gin 750ml',  2600.00, 'Spirits','https://www.diageobaracademy.com/uploads/images/gordons-gin.png', 60),
('J&B Rare Scotch Whisky 750ml', 3200.00, 'Whisky',  'https://www.diageobaracademy.com/uploads/images/jb-rare.png', 40),
('Johnnie Walker Red Label 750ml',3400.00, 'Whisky',  'https://www.diageobaracademy.com/uploads/images/johnnie-walker-red.png', 40),
('Kenya Cane Smooth 750ml',      1800.00, 'Spirits', 'https://drinkiq.com/wp-content/uploads/2020/08/Kenya-Cane.png', 100);

-- ─── ORDERS ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    user_id        INT,
    phone          VARCHAR(20) NOT NULL,
    total          DECIMAL(10,2) NOT NULL,
    status         ENUM('pending','paid','failed','cancelled') DEFAULT 'pending',
    mpesa_code     VARCHAR(30) DEFAULT NULL,
    checkout_req_id VARCHAR(120) DEFAULT NULL,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ─── ORDER ITEMS ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS order_items (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    order_id   INT NOT NULL,
    product_id INT NOT NULL,
    qty        INT NOT NULL DEFAULT 1,
    price      DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id)   REFERENCES orders(id)   ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
);
