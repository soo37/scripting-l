<?php
// mpesa_callback.php — Receives payment result from Safaricom
// This URL must be publicly accessible (HTTPS required by Safaricom)
require_once 'config/db.php';

// Read the raw POST body
$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

// Log all callbacks for debugging
file_put_contents(
    __DIR__ . '/logs/mpesa_callbacks.log',
    date('[Y-m-d H:i:s] ') . $raw . PHP_EOL,
    FILE_APPEND
);

if (!$data) {
    http_response_code(400);
    echo json_encode(['ResultCode' => 1, 'ResultDesc' => 'Bad request']);
    exit;
}

$body            = $data['Body']['stkCallback'] ?? [];
$resultCode      = $body['ResultCode']       ?? -1;
$checkoutReqId   = $body['CheckoutRequestID'] ?? '';

$db   = getDB();
$stmt = $db->prepare("SELECT id FROM orders WHERE checkout_req_id = ? LIMIT 1");
$stmt->execute([$checkoutReqId]);
$order = $stmt->fetch();

if (!$order) {
    echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Order not found']);
    exit;
}

$orderId = $order['id'];

if ($resultCode === 0) {
    // ── Payment successful ──────────────────────────────────────────────────
    $items     = $body['CallbackMetadata']['Item'] ?? [];
    $mpesaCode = '';

    foreach ($items as $item) {
        if ($item['Name'] === 'MpesaReceiptNumber') {
            $mpesaCode = $item['Value'];
        }
    }

    $db->prepare("UPDATE orders SET status = 'paid', mpesa_code = ? WHERE id = ?")
       ->execute([$mpesaCode, $orderId]);

} else {
    // ── Payment failed / cancelled ──────────────────────────────────────────
    $db->prepare("UPDATE orders SET status = 'failed' WHERE id = ?")
       ->execute([$orderId]);
}

// Always respond 200 OK to Safaricom
http_response_code(200);
echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Accepted']);
