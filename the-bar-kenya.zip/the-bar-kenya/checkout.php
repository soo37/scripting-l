<?php
// checkout.php — Saves order to DB, triggers M-Pesa STK Push
require_once 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php'); exit;
}

$cart  = $_SESSION['cart'] ?? [];
$phone = trim($_POST['phone'] ?? '');
$user  = $_SESSION['user']  ?? null;

// ── Validate ──────────────────────────────────────────────────────────────────
if (empty($cart)) {
    $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Cart is empty.'];
    header('Location: index.php#cart'); exit;
}

// Normalize phone: 0712345678 → 254712345678
$phone = preg_replace('/\D/', '', $phone);
if (str_starts_with($phone, '0')) $phone = '254' . substr($phone, 1);

if (!preg_match('/^2547\d{8}$/', $phone)) {
    $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Invalid Safaricom number. Use 07XXXXXXXX.'];
    header('Location: index.php#cart'); exit;
}

// ── Calculate total ───────────────────────────────────────────────────────────
$total = array_sum(array_column($cart, 'subtotal'));

// ── Save order to database ────────────────────────────────────────────────────
$db = getDB();
try {
    $db->beginTransaction();

    $stmt = $db->prepare(
        "INSERT INTO orders (user_id, phone, total, status) VALUES (?, ?, ?, 'pending')"
    );
    $stmt->execute([$user['id'] ?? null, $phone, $total]);
    $orderId = $db->lastInsertId();

    $itemStmt = $db->prepare(
        "INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?, ?, ?, ?)"
    );
    foreach ($cart as $item) {
        $itemStmt->execute([$orderId, $item['product_id'], $item['qty'], $item['price']]);
    }

    $db->commit();
} catch (Exception $e) {
    $db->rollBack();
    $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Order could not be saved. Please try again.'];
    header('Location: index.php#cart'); exit;
}

// ── M-Pesa STK Push ───────────────────────────────────────────────────────────
$stkResult = initiateStkPush($phone, (int)ceil($total), $orderId);

if ($stkResult['success']) {
    // Store the CheckoutRequestID so the callback can match it
    $db->prepare("UPDATE orders SET checkout_req_id = ? WHERE id = ?")
       ->execute([$stkResult['CheckoutRequestID'], $orderId]);

    $_SESSION['cart']  = [];
    $_SESSION['flash'] = [
        'type' => 'success',
        'msg'  => "📲 M-Pesa prompt sent to $phone! Check your phone and enter your PIN. Order #$orderId."
    ];
} else {
    $db->prepare("UPDATE orders SET status = 'failed' WHERE id = ?")->execute([$orderId]);
    $_SESSION['flash'] = [
        'type' => 'error',
        'msg'  => 'M-Pesa STK Push failed: ' . ($stkResult['error'] ?? 'Unknown error')
    ];
}

header('Location: index.php'); exit;

// ── M-Pesa Helper ─────────────────────────────────────────────────────────────
function getMpesaToken(): string {
    $url  = MPESA_ENV === 'live'
        ? 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
        : 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPAUTH       => CURLAUTH_BASIC,
        CURLOPT_USERPWD        => MPESA_CONSUMER_KEY . ':' . MPESA_CONSUMER_SECRET,
    ]);
    $res  = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($res, true);
    return $data['access_token'] ?? '';
}

function initiateStkPush(string $phone, int $amount, int $orderId): array {
    $token = getMpesaToken();
    if (!$token) return ['success' => false, 'error' => 'Could not get M-Pesa token'];

    $timestamp = date('YmdHis');
    $password  = base64_encode(MPESA_SHORTCODE . MPESA_PASSKEY . $timestamp);

    $url  = MPESA_ENV === 'live'
        ? 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest'
        : 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

    $payload = [
        'BusinessShortCode' => MPESA_SHORTCODE,
        'Password'          => $password,
        'Timestamp'         => $timestamp,
        'TransactionType'   => 'CustomerPayBillOnline',
        'Amount'            => $amount,
        'PartyA'            => $phone,
        'PartyB'            => MPESA_SHORTCODE,
        'PhoneNumber'       => $phone,
        'CallBackURL'       => MPESA_CALLBACK_URL,
        'AccountReference'  => 'Order-' . $orderId,
        'TransactionDesc'   => 'The Bar Kenya Order #' . $orderId,
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
        ],
    ]);
    $res  = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($res, true);

    if (isset($data['CheckoutRequestID'])) {
        return ['success' => true, 'CheckoutRequestID' => $data['CheckoutRequestID']];
    }

    return ['success' => false, 'error' => $data['errorMessage'] ?? $data['ResponseDescription'] ?? 'STK failed'];
}
