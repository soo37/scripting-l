# 🍾 The Bar Kenya — PHP Backend Setup

## File Structure
```
the-bar-kenya/
├── config/
│   └── db.php              ← DB credentials + M-Pesa keys
├── logs/
│   └── mpesa_callbacks.log ← Auto-created by callback handler
├── index.php               ← Main storefront
├── auth.php                ← Register / Login / Logout
├── cart.php                ← Session cart (add / remove / clear)
├── checkout.php            ← Save order to DB + STK Push
├── mpesa_callback.php      ← Safaricom payment result webhook
├── admin.php               ← Admin: products, orders, users
└── schema.sql              ← MySQL database setup
```

---

## 1. Database Setup

```bash
mysql -u root -p < schema.sql
```

This creates the `the_bar_kenya` database and seeds products + a default admin user.

**Default admin login:**
- Email: `admin@thebar.co.ke`
- Password: `Admin@1234`

---

## 2. Configure `config/db.php`

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_mysql_user');
define('DB_PASS', 'your_mysql_password');
define('DB_NAME', 'the_bar_kenya');
```

---

## 3. M-Pesa Integration (Daraja API)

1. Register at https://developer.safaricom.co.ke
2. Create an app and get your **Consumer Key** and **Consumer Secret**
3. Get your **Lipa na M-Pesa Passkey** from your paybill settings
4. Update `config/db.php`:

```php
define('MPESA_CONSUMER_KEY',    'your_key');
define('MPESA_CONSUMER_SECRET', 'your_secret');
define('MPESA_SHORTCODE',       '174379');       // your paybill/till
define('MPESA_PASSKEY',         'your_passkey');
define('MPESA_CALLBACK_URL',    'https://yourdomain.com/mpesa_callback.php');
define('MPESA_ENV',             'sandbox');      // change to 'live' for production
```

5. Your **callback URL must be HTTPS** and publicly accessible (not localhost).
   Use [ngrok](https://ngrok.com) for local testing: `ngrok http 80`

---

## 4. Server Requirements

- PHP 8.1+
- MySQL 5.7+ or MariaDB 10.4+
- `curl` extension enabled (`extension=curl` in php.ini)
- Apache/Nginx with `mod_rewrite` (optional but recommended)

---

## 5. Logs

M-Pesa callback payloads are logged to `logs/mpesa_callbacks.log`.
Make sure the `logs/` directory is **writable** by PHP:

```bash
chmod 775 logs/
```

---

## 6. Security Checklist for Production

- [ ] Change default admin password immediately after first login
- [ ] Set `MPESA_ENV` to `'live'`
- [ ] Use a `.env` file or server environment variables instead of hardcoding keys
- [ ] Enable HTTPS (SSL certificate required by M-Pesa)
- [ ] Add `.htaccess` to block direct access to `config/` and `logs/`
- [ ] Use parameterized queries (already done throughout)
- [ ] Set `display_errors = Off` in `php.ini` for production
