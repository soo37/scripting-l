<?php
// index.php — Main storefront
require_once 'config/db.php';

$db       = getDB();
$category = $_GET['cat'] ?? '';
$search   = trim($_GET['q'] ?? '');

$sql    = "SELECT * FROM products WHERE active = 1";
$params = [];

if ($category) {
    $sql    .= " AND category = ?";
    $params[] = $category;
}
if ($search) {
    $sql    .= " AND name LIKE ?";
    $params[] = "%$search%";
}
$sql .= " ORDER BY category, name";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $db->query("SELECT DISTINCT category FROM products WHERE active=1 ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);

$cart  = $_SESSION['cart']  ?? [];
$cartTotal = array_sum(array_column($cart, 'subtotal'));
$user  = $_SESSION['user']  ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>The Bar Kenya | Online Liquor Store</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --gold:   #c9a84c;
    --gold2:  #f0d080;
    --dark:   #0d0d0d;
    --card:   #161616;
    --border: #2a2a2a;
    --text:   #e8e0d0;
    --muted:  #888;
    --green:  #1db954;
  }
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'DM Sans', sans-serif;
    background: var(--dark);
    color: var(--text);
    min-height: 100vh;
  }

  /* AGE GATE */
  #ageGate {
    position: fixed; inset: 0;
    background: #000;
    display: flex; align-items: center; justify-content: center; flex-direction: column;
    z-index: 9999; text-align: center; padding: 30px;
    background-image: radial-gradient(ellipse at 60% 40%, #1a1200 0%, #000 70%);
  }
  #ageGate h2 { font-family: 'Playfair Display', serif; font-size: 2.8rem; color: var(--gold); margin-bottom: 12px; }
  #ageGate p  { color: var(--muted); margin-bottom: 28px; font-size: 1.05rem; }
  #ageGate button {
    background: var(--gold); color: #000; border: none;
    padding: 14px 40px; font-size: 1rem; font-weight: 700;
    border-radius: 2px; cursor: pointer; letter-spacing: .08em;
    transition: background .2s;
  }
  #ageGate button:hover { background: var(--gold2); }

  /* HEADER */
  header {
    background: #080808;
    border-bottom: 1px solid var(--border);
    padding: 18px 32px;
    display: flex; align-items: center; justify-content: space-between;
    position: sticky; top: 0; z-index: 100;
  }
  .logo { font-family: 'Playfair Display', serif; font-size: 1.6rem; color: var(--gold); letter-spacing: .04em; text-decoration: none; }
  .logo span { font-size: .85rem; display: block; color: var(--muted); font-family: 'DM Sans', sans-serif; font-weight: 300; letter-spacing: .12em; }

  nav a {
    color: var(--muted); text-decoration: none; margin-left: 24px;
    font-size: .88rem; letter-spacing: .06em; transition: color .2s;
  }
  nav a:hover { color: var(--gold); }
  .cart-badge {
    background: var(--gold); color: #000;
    font-size: .75rem; font-weight: 700;
    padding: 2px 7px; border-radius: 99px;
    margin-left: 4px;
  }

  /* SEARCH / FILTER BAR */
  .toolbar {
    padding: 20px 32px;
    display: flex; gap: 12px; flex-wrap: wrap; align-items: center;
    border-bottom: 1px solid var(--border);
  }
  .toolbar form { display: flex; gap: 10px; flex: 1; flex-wrap: wrap; }
  .toolbar input[type=text] {
    flex: 1; min-width: 180px;
    background: var(--card); border: 1px solid var(--border);
    color: var(--text); padding: 10px 14px; border-radius: 2px; font-size: .9rem;
  }
  .toolbar select {
    background: var(--card); border: 1px solid var(--border);
    color: var(--text); padding: 10px 14px; border-radius: 2px; font-size: .9rem; cursor: pointer;
  }
  .btn { padding: 10px 22px; border-radius: 2px; border: none; cursor: pointer; font-size: .88rem; font-weight: 600; letter-spacing: .05em; transition: background .2s; }
  .btn-gold  { background: var(--gold);  color: #000; }
  .btn-gold:hover { background: var(--gold2); }
  .btn-green { background: var(--green); color: #fff; }
  .btn-green:hover { background: #17a348; }
  .btn-outline { background: transparent; border: 1px solid var(--border); color: var(--muted); }
  .btn-outline:hover { border-color: var(--gold); color: var(--gold); }

  /* PRODUCT GRID */
  .products {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));
    gap: 1px;
    background: var(--border);
    margin: 0;
  }
  .product {
    background: var(--card);
    padding: 22px 18px;
    display: flex; flex-direction: column; gap: 10px;
    transition: background .2s;
    position: relative;
  }
  .product:hover { background: #1c1c1c; }
  .product img {
    width: 100%; height: 160px; object-fit: contain;
    filter: drop-shadow(0 4px 12px rgba(201,168,76,.15));
    transition: transform .3s;
  }
  .product:hover img { transform: translateY(-4px); }
  .product h3 { font-size: .92rem; color: var(--text); line-height: 1.4; }
  .product .cat { font-size: .75rem; color: var(--muted); text-transform: uppercase; letter-spacing: .08em; }
  .product .price { font-family: 'Playfair Display', serif; font-size: 1.3rem; color: var(--gold); }
  .product .price span { font-size: .75rem; font-family: 'DM Sans', sans-serif; color: var(--muted); }
  .product form { margin-top: auto; }
  .product .add-btn {
    width: 100%; padding: 10px; background: transparent;
    border: 1px solid var(--border); color: var(--muted);
    font-size: .82rem; letter-spacing: .08em; cursor: pointer;
    transition: all .2s; border-radius: 1px;
  }
  .product .add-btn:hover { border-color: var(--gold); color: var(--gold); background: rgba(201,168,76,.06); }
  .qty-row { display: flex; gap: 6px; align-items: center; }
  .qty-row input { width: 52px; text-align: center; background: #0d0d0d; border: 1px solid var(--border); color: var(--text); padding: 7px; border-radius: 2px; }

  /* CART SIDEBAR-STYLE SECTION */
  .cart-section {
    background: var(--card);
    margin: 24px 32px;
    border: 1px solid var(--border);
    border-radius: 2px;
    padding: 28px;
  }
  .cart-section h2 { font-family: 'Playfair Display', serif; font-size: 1.5rem; color: var(--gold); margin-bottom: 20px; }
  table { width: 100%; border-collapse: collapse; }
  th, td { padding: 12px 10px; border-bottom: 1px solid var(--border); font-size: .88rem; text-align: left; }
  th { color: var(--muted); font-weight: 400; letter-spacing: .06em; text-transform: uppercase; font-size: .75rem; }
  td a { color: #c0392b; font-size: .8rem; text-decoration: none; }
  td a:hover { color: #e74c3c; }
  .cart-total { text-align: right; font-family: 'Playfair Display', serif; font-size: 1.6rem; color: var(--gold); margin-top: 16px; }
  .cart-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 16px; }

  /* CHECKOUT FORM */
  .checkout-form { margin-top: 20px; display: none; }
  .checkout-form.show { display: block; }
  .form-group { margin-bottom: 14px; }
  .form-group label { display: block; font-size: .8rem; color: var(--muted); margin-bottom: 6px; letter-spacing: .06em; text-transform: uppercase; }
  .form-group input {
    width: 100%; background: #0d0d0d; border: 1px solid var(--border);
    color: var(--text); padding: 12px 14px; border-radius: 2px; font-size: .95rem;
  }
  .form-group input:focus { outline: none; border-color: var(--gold); }

  /* FLASH MESSAGES */
  .flash { padding: 14px 20px; margin: 16px 32px; border-radius: 2px; font-size: .9rem; }
  .flash.success { background: rgba(29,185,84,.15); border: 1px solid rgba(29,185,84,.3); color: #1db954; }
  .flash.error   { background: rgba(192,57,43,.15);  border: 1px solid rgba(192,57,43,.3);  color: #e74c3c; }

  /* AUTH LINKS */
  .auth-bar { font-size: .82rem; }
  .auth-bar a { color: var(--gold); text-decoration: none; }

  footer {
    background: #080808;
    border-top: 1px solid var(--border);
    text-align: center;
    padding: 22px;
    color: var(--muted);
    font-size: .8rem;
    margin-top: 40px;
    letter-spacing: .06em;
  }

  @media (max-width: 600px) {
    header { flex-direction: column; gap: 12px; }
    .cart-section { margin: 14px; }
    .toolbar { padding: 14px 16px; }
  }
</style>
</head>
<body>

<!-- AGE GATE -->
<div id="ageGate" <?= isset($_COOKIE['age_ok']) ? 'style="display:none"' : '' ?>>
  <h2>🍾 The Bar Kenya</h2>
  <p>You must be 18 years or older to enter this site.<br>Please drink responsibly.</p>
  <button onclick="enterSite()">I am 18+ — Enter</button>
</div>

<!-- HEADER -->
<header>
  <a class="logo" href="index.php">The Bar Kenya <span>ONLINE LIQUOR STORE</span></a>
  <nav>
    <?php if ($user): ?>
      <span style="color:var(--muted);font-size:.85rem">Hi, <?= htmlspecialchars($user['name']) ?></span>
      <?php if ($user['role'] === 'admin'): ?>
        <a href="admin.php">Admin</a>
      <?php endif; ?>
      <a href="auth.php?action=logout">Logout</a>
    <?php else: ?>
      <a href="auth.php?action=login">Login</a>
      <a href="auth.php?action=register">Register</a>
    <?php endif; ?>
    <a href="#cart">
      🛒 Cart
      <?php if (!empty($cart)): ?>
        <span class="cart-badge"><?= count($cart) ?></span>
      <?php endif; ?>
    </a>
  </nav>
</header>

<?php
// Flash messages
if (!empty($_SESSION['flash'])):
  $f = $_SESSION['flash']; unset($_SESSION['flash']);
?>
  <div class="flash <?= $f['type'] ?>"><?= htmlspecialchars($f['msg']) ?></div>
<?php endif; ?>

<!-- SEARCH / FILTER -->
<div class="toolbar">
  <form method="GET" action="index.php">
    <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search drinks…">
    <select name="cat">
      <option value="">All Categories</option>
      <?php foreach ($categories as $cat): ?>
        <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>>
          <?= htmlspecialchars($cat) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-gold" type="submit">Search</button>
    <a href="index.php" class="btn btn-outline">Clear</a>
  </form>
</div>

<!-- PRODUCT GRID -->
<section class="products">
<?php foreach ($products as $p): ?>
  <div class="product">
    <img src="<?= htmlspecialchars($p['img_url']) ?>"
         onerror="this.src='https://via.placeholder.com/200x180?text=No+Image'"
         alt="<?= htmlspecialchars($p['name']) ?>">
    <div class="cat"><?= htmlspecialchars($p['category']) ?></div>
    <h3><?= htmlspecialchars($p['name']) ?></h3>
    <div class="price">KES <?= number_format($p['price'], 0) ?> <span>/ unit</span></div>
    <form method="POST" action="cart.php">
      <input type="hidden" name="action" value="add">
      <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
      <div class="qty-row">
        <input type="number" name="qty" value="1" min="1" max="<?= $p['stock'] ?>">
        <button type="submit" class="add-btn" style="flex:1">+ Add to Cart</button>
      </div>
    </form>
  </div>
<?php endforeach; ?>
<?php if (empty($products)): ?>
  <p style="padding:40px;color:var(--muted);grid-column:1/-1">No products found.</p>
<?php endif; ?>
</section>

<!-- CART -->
<div class="cart-section" id="cart">
  <h2>🛒 Shopping Cart</h2>
  <?php if (empty($cart)): ?>
    <p style="color:var(--muted)">Your cart is empty.</p>
  <?php else: ?>
    <table>
      <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Subtotal</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($cart as $idx => $item): ?>
          <tr>
            <td><?= htmlspecialchars($item['name']) ?></td>
            <td><?= $item['qty'] ?></td>
            <td>KES <?= number_format($item['price'], 0) ?></td>
            <td>KES <?= number_format($item['subtotal'], 0) ?></td>
            <td>
              <a href="cart.php?action=remove&idx=<?= $idx ?>">Remove</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <div class="cart-total">Total: KES <?= number_format($cartTotal, 0) ?></div>

    <div class="cart-actions">
      <a href="cart.php?action=clear" class="btn btn-outline">Clear Cart</a>
      <button onclick="document.getElementById('checkoutForm').classList.toggle('show')" class="btn btn-gold">
        Checkout via M-Pesa
      </button>
    </div>

    <!-- CHECKOUT FORM -->
    <div class="checkout-form" id="checkoutForm">
      <form method="POST" action="checkout.php">
        <div class="form-group">
          <label>Safaricom Phone Number</label>
          <input type="tel" name="phone"
                 value="<?= htmlspecialchars($user['phone'] ?? '') ?>"
                 placeholder="07XXXXXXXX" required>
        </div>
        <button type="submit" class="btn btn-green" style="width:100%;padding:14px">
          📲 Send M-Pesa STK Push — KES <?= number_format($cartTotal, 0) ?>
        </button>
      </form>
    </div>
  <?php endif; ?>
</div>

<footer>© <?= date('Y') ?> The Bar Kenya | 18+ Only | Drink Responsibly</footer>

<script>
  function enterSite() {
    document.getElementById('ageGate').style.display = 'none';
    document.cookie = "age_ok=1; max-age=" + (60*60*24*30) + "; path=/";
  }
</script>
</body>
</html>
