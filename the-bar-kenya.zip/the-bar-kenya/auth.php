<?php
// auth.php — Register, Login, Logout
require_once 'config/db.php';

$action = $_GET['action'] ?? 'login';
$error  = '';
$db     = getDB();

// ── LOGOUT ────────────────────────────────────────────────────────────────────
if ($action === 'logout') {
    $_SESSION = [];
    session_destroy();
    header('Location: index.php'); exit;
}

// ── PROCESS POST ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? $action;

    if ($action === 'register') {
        $name     = trim($_POST['name']     ?? '');
        $email    = strtolower(trim($_POST['email'] ?? ''));
        $phone    = trim($_POST['phone']    ?? '');
        $password = $_POST['password']      ?? '';
        $confirm  = $_POST['confirm']       ?? '';

        if (!$name || !$email || !$phone || !$password) {
            $error = 'All fields are required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email address.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            // Check duplicate email
            $check = $db->prepare("SELECT id FROM users WHERE email = ?");
            $check->execute([$email]);
            if ($check->fetch()) {
                $error = 'Email already registered.';
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
                $stmt = $db->prepare(
                    "INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)"
                );
                $stmt->execute([$name, $email, $phone, $hash]);
                $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Account created! Please log in.'];
                header('Location: auth.php?action=login'); exit;
            }
        }

    } elseif ($action === 'login') {
        $email    = strtolower(trim($_POST['email']    ?? ''));
        $password = $_POST['password'] ?? '';

        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = [
                'id'    => $user['id'],
                'name'  => $user['name'],
                'email' => $user['email'],
                'phone' => $user['phone'],
                'role'  => $user['role'],
            ];
            session_regenerate_id(true);
            header('Location: index.php'); exit;
        } else {
            $error = 'Invalid email or password.';
        }
    }
}

$isRegister = ($action === 'register');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= $isRegister ? 'Register' : 'Login' ?> | The Bar Kenya</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  :root { --gold:#c9a84c; --dark:#0d0d0d; --card:#161616; --border:#2a2a2a; --text:#e8e0d0; --muted:#888; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'DM Sans', sans-serif; background: var(--dark); color: var(--text); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
  .box {
    background: var(--card); border: 1px solid var(--border); border-radius: 2px;
    padding: 42px 48px; width: 100%; max-width: 440px;
  }
  h1 { font-family: 'Playfair Display', serif; color: var(--gold); font-size: 1.8rem; margin-bottom: 6px; }
  .sub { color: var(--muted); font-size: .85rem; margin-bottom: 28px; }
  .sub a { color: var(--gold); text-decoration: none; }
  label { display: block; font-size: .75rem; color: var(--muted); letter-spacing: .07em; text-transform: uppercase; margin-bottom: 6px; }
  input {
    width: 100%; background: #0d0d0d; border: 1px solid var(--border);
    color: var(--text); padding: 12px 14px; border-radius: 2px; font-size: .95rem; margin-bottom: 18px;
  }
  input:focus { outline: none; border-color: var(--gold); }
  button {
    width: 100%; background: var(--gold); color: #000;
    border: none; padding: 14px; font-size: 1rem; font-weight: 700;
    border-radius: 2px; cursor: pointer; letter-spacing: .06em;
  }
  button:hover { background: #f0d080; }
  .error { background: rgba(192,57,43,.15); border: 1px solid rgba(192,57,43,.3); color: #e74c3c; padding: 12px 14px; border-radius: 2px; font-size: .88rem; margin-bottom: 18px; }
  .back { display: block; text-align: center; margin-top: 20px; color: var(--muted); font-size: .82rem; }
  .back a { color: var(--gold); text-decoration: none; }
</style>
</head>
<body>
<div class="box">
  <h1><?= $isRegister ? 'Create Account' : 'Welcome Back' ?></h1>
  <p class="sub">
    <?php if ($isRegister): ?>
      Already have an account? <a href="auth.php?action=login">Sign in</a>
    <?php else: ?>
      No account yet? <a href="auth.php?action=register">Register free</a>
    <?php endif; ?>
  </p>

  <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

  <form method="POST" action="auth.php">
    <input type="hidden" name="action" value="<?= $isRegister ? 'register' : 'login' ?>">

    <?php if ($isRegister): ?>
      <label>Full Name</label>
      <input type="text" name="name" required placeholder="John Doe">
    <?php endif; ?>

    <label>Email Address</label>
    <input type="email" name="email" required placeholder="you@example.com">

    <?php if ($isRegister): ?>
      <label>Phone (Safaricom)</label>
      <input type="tel" name="phone" required placeholder="07XXXXXXXX">
    <?php endif; ?>

    <label>Password</label>
    <input type="password" name="password" required placeholder="••••••••">

    <?php if ($isRegister): ?>
      <label>Confirm Password</label>
      <input type="password" name="confirm" required placeholder="••••••••">
    <?php endif; ?>

    <button type="submit"><?= $isRegister ? 'Create Account' : 'Sign In' ?></button>
  </form>

  <span class="back"><a href="index.php">← Back to Store</a></span>
</div>
</body>
</html>
