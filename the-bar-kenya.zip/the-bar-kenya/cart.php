<?php
// cart.php — Session-based cart actions
require_once 'config/db.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'add') {
    $productId = (int)($_POST['product_id'] ?? 0);
    $qty       = max(1, (int)($_POST['qty'] ?? 1));

    $db   = getDB();
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ? AND active = 1");
    $stmt->execute([$productId]);
    $product = $stmt->fetch();

    if ($product) {
        if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

        // Check if already in cart → increase qty
        $found = false;
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['product_id'] === $productId) {
                $item['qty']      += $qty;
                $item['subtotal']  = $item['qty'] * $item['price'];
                $found = true;
                break;
            }
        }
        unset($item);

        if (!$found) {
            $_SESSION['cart'][] = [
                'product_id' => $productId,
                'name'       => $product['name'],
                'price'      => (float)$product['price'],
                'qty'        => $qty,
                'subtotal'   => (float)$product['price'] * $qty,
            ];
        }

        $_SESSION['flash'] = ['type' => 'success', 'msg' => "'{$product['name']}' added to cart!"];
    } else {
        $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Product not found.'];
    }

} elseif ($action === 'remove') {
    $idx = (int)($_GET['idx'] ?? -1);
    if (isset($_SESSION['cart'][$idx])) {
        array_splice($_SESSION['cart'], $idx, 1);
    }

} elseif ($action === 'clear') {
    $_SESSION['cart'] = [];
}

header('Location: index.php#cart');
exit;
